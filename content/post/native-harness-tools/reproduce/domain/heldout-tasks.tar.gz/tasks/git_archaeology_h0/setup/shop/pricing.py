# pricing helpers (rev 4)
def total(items, discount=0.0):
    """Sum price * quantity over items, then apply a fractional discount."""
    lines = [price * qty * (1 - discount) for price, qty in items]
    return round(sum(lines) * (1 - discount), 2)
