VERSION = '1.39'


def banner():
    return 'shop ' + VERSION
