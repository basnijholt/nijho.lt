from pricing import total

result = total([(33.03, 3), (6.63, 3), (16.37, 6)], discount=0.25)
assert result == 162.9, result
print('ok', result)
