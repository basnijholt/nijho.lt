The helper `fetch_rows` is used by every module; `fetch_rows_cached` wraps it.
