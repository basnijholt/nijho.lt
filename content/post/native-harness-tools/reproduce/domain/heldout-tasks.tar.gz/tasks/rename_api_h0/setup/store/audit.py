from store import db


def audit_1():
    return len(db.fetch_rows("t1"))
