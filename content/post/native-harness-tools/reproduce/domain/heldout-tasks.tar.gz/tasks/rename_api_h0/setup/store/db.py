LOG_PREFIX = "fetch_rows:"


def fetch_rows(table):
    """Return the rows of a table."""
    return [{"table": table, "n": i} for i in range(3)]


def fetch_rows_cached(table):
    """Cached variant; a different function."""
    return fetch_rows(table)
