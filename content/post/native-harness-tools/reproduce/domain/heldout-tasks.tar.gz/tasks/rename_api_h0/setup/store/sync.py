from store.db import fetch_rows


def sync_0():
    return len(fetch_rows("t0"))
