from store.db import fetch_rows_cached


def report_2():
    return len(fetch_rows_cached("t2"))
