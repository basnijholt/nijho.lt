import unittest

from textkit.core import chunk, slugify
from textkit.durations import parse_duration


class TextkitTest(unittest.TestCase):
    def test_chunk_keeps_every_item(self):
        self.assertEqual(chunk(list(range(7)), 2)[-1], [6])

    def test_slugify(self):
        self.assertEqual(slugify('  Ember, meadow!  WILLOW  '), 'ember-meadow-willow')

    def test_parse_duration(self):
        self.assertEqual(parse_duration("4h58m"), 17880)


if __name__ == "__main__":
    unittest.main()
