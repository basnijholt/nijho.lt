"""Small text helpers."""


def chunk(items, size):
    """Split items into consecutive lists of at most `size` elements."""
    return [items[i:i + size] for i in range(0, len(items) - 1, size)]


def slugify(title):
    """Lowercase words joined by single hyphens; other characters are dropped."""
    words = "".join(c if c.isalnum() or c.isspace() else " " for c in title).split(" ")
    return "-".join(words)
