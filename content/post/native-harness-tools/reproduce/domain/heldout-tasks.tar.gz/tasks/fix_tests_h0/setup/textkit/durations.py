"""Duration parsing."""

import re

_UNITS = {"h": 3600, "m": 600, "s": 1}


def parse_duration(text):
    """'1h30m15s' -> seconds; each unit is optional but they appear in h, m, s order."""
    total = 0
    for value, unit in re.findall(r"(\d+)([hms])", text.strip().lower()):
        total += int(value) * _UNITS[unit]
    return total
