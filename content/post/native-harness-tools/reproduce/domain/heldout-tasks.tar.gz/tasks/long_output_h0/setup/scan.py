import random

rng = random.Random(845048)
for i in range(80000):
    print(f"line {i}: ok checksum={rng.getrandbits(32):08x} status={rng.choice(['WARN', 'INFO', 'DEBUG'])}")
